import os
import django

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'procurement_project.settings')
django.setup()

from django.contrib.auth.models import User, Group

print("--- เริ่มการสร้าง Groups และ Users ---")

# 1. Create Groups
officer_group, _ = Group.objects.get_or_create(name='พนักงานจัดซื้อ')
manager_group, _ = Group.objects.get_or_create(name='หัวหน้าแผนกจัดซื้อ')
print("✅ สร้าง Groups สำเร็จ")

# 2. Create Admin (Superuser)
admin_user, created = User.objects.get_or_create(username='admin')
admin_user.set_password('admin1234')
admin_user.is_superuser = True
admin_user.is_staff = True
admin_user.save()
print("✅ สร้าง Admin (admin / admin1234) สำเร็จ")

# 3. Create Manager
manager_user, created = User.objects.get_or_create(username='manager')
manager_user.set_password('manager1234')
manager_user.save()
manager_user.groups.add(manager_group)
print("✅ สร้างหัวหน้าแผนกจัดซื้อ (manager / manager1234) สำเร็จ")

# 4. Create Officer
officer_user, created = User.objects.get_or_create(username='officer')
officer_user.set_password('officer1234')
officer_user.save()
officer_user.groups.add(officer_group)
print("✅ สร้างพนักงานจัดซื้อ (officer / officer1234) สำเร็จ")

# 5. Create General User
general_user, created = User.objects.get_or_create(username='user')
general_user.set_password('user1234')
general_user.save()
print("✅ สร้างผู้ใช้ทั่วไป (user / user1234) สำเร็จ")

print("\n🎉 สร้างข้อมูลเสร็จสมบูรณ์ คุณสามารถนำ Username และ Password ด้านบนไปทดสอบระบบได้เลย!")
