from django.contrib.auth.models import Group

# Create groups
officer_group, created = Group.objects.get_or_create(name='พนักงานจัดซื้อ')
if created:
    print("Created group: พนักงานจัดซื้อ")
else:
    print("Group 'พนักงานจัดซื้อ' already exists")

manager_group, created = Group.objects.get_or_create(name='หัวหน้าแผนกจัดซื้อ')
if created:
    print("Created group: หัวหน้าแผนกจัดซื้อ")
else:
    print("Group 'หัวหน้าแผนกจัดซื้อ' already exists")

print("Group creation complete. Please assign users to these groups via Django Admin.")
