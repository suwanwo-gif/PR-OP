from django.urls import path
from . import views

urlpatterns = [
    # Dashboard
    path('', views.dashboard, name='dashboard'),

    # Vendors
    path('vendors/', views.vendor_list, name='vendor_list'),
    path('vendors/create/', views.vendor_create, name='vendor_create'),
    path('vendors/<int:pk>/edit/', views.vendor_edit, name='vendor_edit'),
    path('vendors/<int:pk>/delete/', views.vendor_delete, name='vendor_delete'),

    # Items
    path('items/', views.item_list, name='item_list'),
    path('items/create/', views.item_create, name='item_create'),
    path('items/<int:pk>/edit/', views.item_edit, name='item_edit'),
    path('items/<int:pk>/delete/', views.item_delete, name='item_delete'),

    # Purchase Requisitions
    path('pr/', views.pr_list, name='pr_list'),
    path('pr/create/', views.pr_create, name='pr_create'),
    path('pr/<int:pk>/', views.pr_detail, name='pr_detail'),
    path('pr/<int:pk>/edit/', views.pr_edit, name='pr_edit'),
    path('pr/<int:pk>/delete/', views.pr_delete, name='pr_delete'),
    path('pr/<int:pk>/approve/', views.pr_approve, name='pr_approve'),

    # Purchase Orders
    path('po/', views.po_list, name='po_list'),
    path('po/create/', views.po_create, name='po_create'),
    path('po/<int:pk>/', views.po_detail, name='po_detail'),
    path('po/<int:pk>/edit/', views.po_edit, name='po_edit'),
    path('po/<int:pk>/delete/', views.po_delete, name='po_delete'),
    path('po/<int:pk>/approve/', views.po_approve, name='po_approve'),

    # Goods Receipts
    path('gr/', views.gr_list, name='gr_list'),
    path('gr/create/', views.gr_create, name='gr_create'),
    path('gr/<int:pk>/', views.gr_detail, name='gr_detail'),
    path('gr/<int:pk>/edit/', views.gr_edit, name='gr_edit'),
    path('gr/<int:pk>/delete/', views.gr_delete, name='gr_delete'),
]
