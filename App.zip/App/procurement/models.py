from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User


# ===== Master Data =====

class Vendor(models.Model):
    """ผู้ขาย / Supplier"""
    vendor_code = models.CharField('รหัสผู้ขาย', max_length=20, unique=True)
    vendor_name = models.CharField('ชื่อผู้ขาย', max_length=200)
    tax_id = models.CharField('เลขประจำตัวผู้เสียภาษี', max_length=20, blank=True, default='')
    credit_term_days = models.IntegerField('เครดิต (วัน)', default=30)

    class Meta:
        verbose_name = 'ผู้ขาย'
        verbose_name_plural = 'ผู้ขาย'
        ordering = ['vendor_code']

    def __str__(self):
        return f"{self.vendor_code} - {self.vendor_name}"


class Item(models.Model):
    """รายการสินค้า / วัสดุ"""
    CATEGORY_CHOICES = [
        ('วัสดุสำนักงาน', 'วัสดุสำนักงาน'),
        ('อุปกรณ์คอมพิวเตอร์', 'อุปกรณ์คอมพิวเตอร์'),
        ('วัสดุก่อสร้าง', 'วัสดุก่อสร้าง'),
        ('อุปกรณ์ไฟฟ้า', 'อุปกรณ์ไฟฟ้า'),
        ('วัสดุทำความสะอาด', 'วัสดุทำความสะอาด'),
        ('อื่นๆ', 'อื่นๆ'),
    ]
    item_code = models.CharField('รหัสสินค้า', max_length=20, unique=True)
    item_name = models.CharField('ชื่อสินค้า', max_length=200)
    category = models.CharField('หมวดหมู่', max_length=50, choices=CATEGORY_CHOICES, default='อื่นๆ')
    uom = models.CharField('หน่วยนับ', max_length=20, default='ชิ้น')

    class Meta:
        verbose_name = 'สินค้า'
        verbose_name_plural = 'สินค้า'
        ordering = ['item_code']

    def __str__(self):
        return f"{self.item_code} - {self.item_name}"


# ===== Purchase Requisition (ใบขอซื้อ) =====

class PurchaseRequisition(models.Model):
    """ใบขอซื้อ (PR)"""
    STATUS_CHOICES = [
        ('ร่าง', 'ร่าง'),
        ('รออนุมัติ', 'รออนุมัติ'),
        ('อนุมัติ', 'อนุมัติ'),
        ('ไม่อนุมัติ', 'ไม่อนุมัติ'),
        ('ยกเลิก', 'ยกเลิก'),
    ]
    pr_number = models.CharField('เลขที่ PR', max_length=20, unique=True, blank=True)
    requester_user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, verbose_name='ผู้ขอซื้อ (ระบบ)')
    requester_name = models.CharField('ชื่อผู้ขอซื้อ (พิมพ์)', max_length=100)
    department = models.CharField('แผนก', max_length=100)
    status = models.CharField('สถานะ', max_length=20, choices=STATUS_CHOICES, default='ร่าง')
    request_date = models.DateField('วันที่ขอซื้อ', default=timezone.now)

    class Meta:
        verbose_name = 'ใบขอซื้อ'
        verbose_name_plural = 'ใบขอซื้อ'
        ordering = ['-request_date', '-id']

    def __str__(self):
        return self.pr_number

    def save(self, *args, **kwargs):
        if not self.pr_number:
            today_str = timezone.now().strftime('%Y%m')
            last_pr = PurchaseRequisition.objects.filter(pr_number__startswith=f'PR-{today_str}-').order_by('id').last()
            if last_pr:
                try:
                    last_num = int(last_pr.pr_number.split('-')[-1])
                    new_num = last_num + 1
                except ValueError:
                    new_num = 1
            else:
                new_num = 1
            self.pr_number = f"PR-{today_str}-{new_num:03d}"
        super().save(*args, **kwargs)

    @property
    def total_estimated_amount(self):
        return sum(
            line.quantity * line.estimated_unit_price
            for line in self.lines.all()
        )


class PRLine(models.Model):
    """รายการในใบขอซื้อ"""
    pr = models.ForeignKey(PurchaseRequisition, on_delete=models.CASCADE, related_name='lines', verbose_name='ใบขอซื้อ')
    item = models.ForeignKey(Item, on_delete=models.PROTECT, verbose_name='สินค้า')
    quantity = models.DecimalField('จำนวน', max_digits=12, decimal_places=2)
    estimated_unit_price = models.DecimalField('ราคาประมาณการต่อหน่วย', max_digits=12, decimal_places=2)

    class Meta:
        verbose_name = 'รายการใบขอซื้อ'
        verbose_name_plural = 'รายการใบขอซื้อ'

    def __str__(self):
        return f"{self.pr.pr_number} - {self.item.item_name}"

    @property
    def estimated_total(self):
        return self.quantity * self.estimated_unit_price


# ===== Purchase Order (ใบสั่งซื้อ) =====

class PurchaseOrder(models.Model):
    """ใบสั่งซื้อ (PO)"""
    STATUS_CHOICES = [
        ('ร่าง', 'ร่าง'),
        ('ออกแล้ว', 'ออกแล้ว'),
        ('รับของครบ', 'รับของครบ'),
        ('รับของบางส่วน', 'รับของบางส่วน'),
        ('ยกเลิก', 'ยกเลิก'),
    ]
    po_number = models.CharField('เลขที่ PO', max_length=20, unique=True, blank=True)
    vendor = models.ForeignKey(Vendor, on_delete=models.PROTECT, verbose_name='ผู้ขาย')
    status = models.CharField('สถานะ', max_length=20, choices=STATUS_CHOICES, default='ร่าง')
    order_date = models.DateField('วันที่สั่งซื้อ', default=timezone.now)
    total_amount = models.DecimalField('ยอดรวม', max_digits=14, decimal_places=2, default=0)

    class Meta:
        verbose_name = 'ใบสั่งซื้อ'
        verbose_name_plural = 'ใบสั่งซื้อ'
        ordering = ['-order_date', '-id']

    def __str__(self):
        return self.po_number

    def save(self, *args, **kwargs):
        if not self.po_number:
            today_str = timezone.now().strftime('%Y%m')
            last_po = PurchaseOrder.objects.filter(po_number__startswith=f'PO-{today_str}-').order_by('id').last()
            if last_po:
                try:
                    last_num = int(last_po.po_number.split('-')[-1])
                    new_num = last_num + 1
                except ValueError:
                    new_num = 1
            else:
                new_num = 1
            self.po_number = f"PO-{today_str}-{new_num:03d}"
        super().save(*args, **kwargs)

    def recalculate_total(self):
        self.total_amount = sum(
            line.quantity * line.unit_price
            for line in self.lines.all()
        )
        self.save(update_fields=['total_amount'])


class POLine(models.Model):
    """รายการในใบสั่งซื้อ"""
    po = models.ForeignKey(PurchaseOrder, on_delete=models.CASCADE, related_name='lines', verbose_name='ใบสั่งซื้อ')
    pr_line = models.ForeignKey(PRLine, on_delete=models.SET_NULL, null=True, blank=True, verbose_name='อ้างอิง PR Line')
    item = models.ForeignKey(Item, on_delete=models.PROTECT, verbose_name='สินค้า')
    quantity = models.DecimalField('จำนวนสั่งซื้อ', max_digits=12, decimal_places=2)
    unit_price = models.DecimalField('ราคาต่อหน่วย', max_digits=12, decimal_places=2)
    received_qty = models.DecimalField('จำนวนที่รับแล้ว', max_digits=12, decimal_places=2, default=0)

    class Meta:
        verbose_name = 'รายการใบสั่งซื้อ'
        verbose_name_plural = 'รายการใบสั่งซื้อ'

    def __str__(self):
        return f"{self.po.po_number} - {self.item.item_name}"

    @property
    def line_total(self):
        return self.quantity * self.unit_price

    @property
    def remaining_qty(self):
        return self.quantity - self.received_qty


# ===== Goods Receipt (ใบรับของ) =====

class GoodsReceipt(models.Model):
    """ใบรับของ (GR)"""
    gr_number = models.CharField('เลขที่ GR', max_length=20, unique=True)
    po = models.ForeignKey(PurchaseOrder, on_delete=models.PROTECT, verbose_name='ใบสั่งซื้อ')
    receiver_name = models.CharField('ผู้รับของ', max_length=100)
    receipt_date = models.DateField('วันที่รับของ', default=timezone.now)

    class Meta:
        verbose_name = 'ใบรับของ'
        verbose_name_plural = 'ใบรับของ'
        ordering = ['-receipt_date', '-id']

    def __str__(self):
        return self.gr_number


class GRLine(models.Model):
    """รายการในใบรับของ"""
    CONDITION_CHOICES = [
        ('ปกติ', 'ปกติ'),
        ('ชำรุด', 'ชำรุด'),
        ('ไม่ตรงสเปค', 'ไม่ตรงสเปค'),
    ]
    gr = models.ForeignKey(GoodsReceipt, on_delete=models.CASCADE, related_name='lines', verbose_name='ใบรับของ')
    po_line = models.ForeignKey(POLine, on_delete=models.PROTECT, verbose_name='อ้างอิง PO Line')
    item = models.ForeignKey(Item, on_delete=models.PROTECT, verbose_name='สินค้า')
    received_qty = models.DecimalField('จำนวนที่รับ', max_digits=12, decimal_places=2)
    condition_status = models.CharField('สภาพ', max_length=20, choices=CONDITION_CHOICES, default='ปกติ')

    class Meta:
        verbose_name = 'รายการใบรับของ'
        verbose_name_plural = 'รายการใบรับของ'

    def __str__(self):
        return f"{self.gr.gr_number} - {self.item.item_name}"
