from django.contrib import admin
from .models import (
    Vendor, Item,
    PurchaseRequisition, PRLine,
    PurchaseOrder, POLine,
    GoodsReceipt, GRLine,
)


class PRLineInline(admin.TabularInline):
    model = PRLine
    extra = 1


class POLineInline(admin.TabularInline):
    model = POLine
    extra = 1


class GRLineInline(admin.TabularInline):
    model = GRLine
    extra = 1


@admin.register(Vendor)
class VendorAdmin(admin.ModelAdmin):
    list_display = ['vendor_code', 'vendor_name', 'tax_id', 'credit_term_days']
    search_fields = ['vendor_code', 'vendor_name']


@admin.register(Item)
class ItemAdmin(admin.ModelAdmin):
    list_display = ['item_code', 'item_name', 'category', 'uom']
    search_fields = ['item_code', 'item_name']
    list_filter = ['category']


@admin.register(PurchaseRequisition)
class PurchaseRequisitionAdmin(admin.ModelAdmin):
    list_display = ['pr_number', 'requester_name', 'department', 'status', 'request_date']
    search_fields = ['pr_number', 'requester_name']
    list_filter = ['status', 'department']
    inlines = [PRLineInline]


@admin.register(PurchaseOrder)
class PurchaseOrderAdmin(admin.ModelAdmin):
    list_display = ['po_number', 'vendor', 'status', 'order_date', 'total_amount']
    search_fields = ['po_number', 'vendor__vendor_name']
    list_filter = ['status']
    inlines = [POLineInline]


@admin.register(GoodsReceipt)
class GoodsReceiptAdmin(admin.ModelAdmin):
    list_display = ['gr_number', 'po', 'receiver_name', 'receipt_date']
    search_fields = ['gr_number', 'po__po_number']
    inlines = [GRLineInline]
