"""
Management command to seed sample data for the procurement system.
Usage: py manage.py seed_data
"""
import random
from datetime import timedelta
from django.core.management.base import BaseCommand
from django.utils import timezone
from procurement.models import (
    Vendor, Item,
    PurchaseRequisition, PRLine,
    PurchaseOrder, POLine,
    GoodsReceipt, GRLine,
)


class Command(BaseCommand):
    help = 'เพิ่มข้อมูลตัวอย่างลงในระบบจัดซื้อจัดจ้าง'

    def handle(self, *args, **options):
        self.stdout.write('กำลังเพิ่มข้อมูลตัวอย่าง...')

        # === Vendors ===
        vendors_data = [
            {'vendor_code': 'VND-001', 'vendor_name': 'บริษัท สยามเทค ซัพพลาย จำกัด', 'tax_id': '0105558012345', 'credit_term_days': 30},
            {'vendor_code': 'VND-002', 'vendor_name': 'บริษัท อิเล็กทรอนิกส์ โปร จำกัด', 'tax_id': '0105561023456', 'credit_term_days': 45},
            {'vendor_code': 'VND-003', 'vendor_name': 'ห้างหุ้นส่วนจำกัด กรุงเทพออฟฟิศ', 'tax_id': '0105559034567', 'credit_term_days': 15},
            {'vendor_code': 'VND-004', 'vendor_name': 'บริษัท คลีนเซอร์วิส จำกัด', 'tax_id': '0105562045678', 'credit_term_days': 30},
            {'vendor_code': 'VND-005', 'vendor_name': 'บริษัท บิลด์มาสเตอร์ จำกัด', 'tax_id': '0105563056789', 'credit_term_days': 60},
        ]
        vendors = []
        for v in vendors_data:
            vendor, _ = Vendor.objects.get_or_create(vendor_code=v['vendor_code'], defaults=v)
            vendors.append(vendor)
        self.stdout.write(f'  ✓ ผู้ขาย {len(vendors)} ราย')

        # === Items ===
        items_data = [
            {'item_code': 'ITM-001', 'item_name': 'กระดาษ A4 80 แกรม', 'category': 'วัสดุสำนักงาน', 'uom': 'รีม'},
            {'item_code': 'ITM-002', 'item_name': 'หมึกพิมพ์ HP 680 สีดำ', 'category': 'วัสดุสำนักงาน', 'uom': 'ตลับ'},
            {'item_code': 'ITM-003', 'item_name': 'โน้ตบุ๊ค ASUS VivoBook 15', 'category': 'อุปกรณ์คอมพิวเตอร์', 'uom': 'เครื่อง'},
            {'item_code': 'ITM-004', 'item_name': 'เมาส์ไร้สาย Logitech M330', 'category': 'อุปกรณ์คอมพิวเตอร์', 'uom': 'ชิ้น'},
            {'item_code': 'ITM-005', 'item_name': 'สาย LAN Cat6 305m', 'category': 'อุปกรณ์คอมพิวเตอร์', 'uom': 'กล่อง'},
            {'item_code': 'ITM-006', 'item_name': 'ปูนซีเมนต์ตราเสือ', 'category': 'วัสดุก่อสร้าง', 'uom': 'ถุง'},
            {'item_code': 'ITM-007', 'item_name': 'หลอดไฟ LED 18W', 'category': 'อุปกรณ์ไฟฟ้า', 'uom': 'หลอด'},
            {'item_code': 'ITM-008', 'item_name': 'น้ำยาทำความสะอาดอเนกประสงค์', 'category': 'วัสดุทำความสะอาด', 'uom': 'แกลลอน'},
            {'item_code': 'ITM-009', 'item_name': 'คีย์บอร์ด Mechanical', 'category': 'อุปกรณ์คอมพิวเตอร์', 'uom': 'ชิ้น'},
            {'item_code': 'ITM-010', 'item_name': 'ปากกาลูกลื่น', 'category': 'วัสดุสำนักงาน', 'uom': 'กล่อง'},
        ]
        items = []
        for i in items_data:
            item, _ = Item.objects.get_or_create(item_code=i['item_code'], defaults=i)
            items.append(item)
        self.stdout.write(f'  ✓ สินค้า {len(items)} รายการ')

        # === Purchase Requisitions ===
        today = timezone.now().date()
        pr_data = [
            {'pr_number': 'PR-2026-001', 'requester_name': 'สมชาย สมบูรณ์', 'department': 'ฝ่ายจัดซื้อ', 'status': 'อนุมัติ', 'request_date': today - timedelta(days=15)},
            {'pr_number': 'PR-2026-002', 'requester_name': 'สุภาพร ใจดี', 'department': 'ฝ่ายไอที', 'status': 'อนุมัติ', 'request_date': today - timedelta(days=10)},
            {'pr_number': 'PR-2026-003', 'requester_name': 'วิทยา ศรีสุข', 'department': 'ฝ่ายบริหาร', 'status': 'รออนุมัติ', 'request_date': today - timedelta(days=5)},
            {'pr_number': 'PR-2026-004', 'requester_name': 'พิมพ์ใจ วงศ์ดี', 'department': 'ฝ่ายบัญชี', 'status': 'ร่าง', 'request_date': today - timedelta(days=2)},
            {'pr_number': 'PR-2026-005', 'requester_name': 'ธนกร แสงทอง', 'department': 'ฝ่ายไอที', 'status': 'รออนุมัติ', 'request_date': today},
        ]
        prs = []
        for p in pr_data:
            pr, created = PurchaseRequisition.objects.get_or_create(pr_number=p['pr_number'], defaults=p)
            prs.append(pr)
            if created:
                # Add 2-3 lines per PR
                selected_items = random.sample(items, min(3, len(items)))
                for item in selected_items:
                    PRLine.objects.create(
                        pr=pr, item=item,
                        quantity=random.randint(5, 50),
                        estimated_unit_price=random.choice([120, 250, 450, 890, 1500, 18900, 3200])
                    )
        self.stdout.write(f'  ✓ ใบขอซื้อ {len(prs)} ใบ')

        # === Purchase Orders ===
        po_data = [
            {'po_number': 'PO-2026-001', 'vendor': vendors[0], 'status': 'รับของครบ', 'order_date': today - timedelta(days=12)},
            {'po_number': 'PO-2026-002', 'vendor': vendors[1], 'status': 'ออกแล้ว', 'order_date': today - timedelta(days=8)},
            {'po_number': 'PO-2026-003', 'vendor': vendors[2], 'status': 'รับของบางส่วน', 'order_date': today - timedelta(days=5)},
            {'po_number': 'PO-2026-004', 'vendor': vendors[3], 'status': 'ร่าง', 'order_date': today},
        ]
        pos = []
        for p in po_data:
            po, created = PurchaseOrder.objects.get_or_create(po_number=p['po_number'], defaults=p)
            pos.append(po)
            if created:
                selected_items = random.sample(items, min(3, len(items)))
                total = 0
                for item in selected_items:
                    qty = random.randint(5, 30)
                    price = random.choice([120, 250, 450, 890, 1500, 18900])
                    received = qty if po.status == 'รับของครบ' else (random.randint(1, qty-1) if po.status == 'รับของบางส่วน' else 0)
                    POLine.objects.create(
                        po=po, item=item,
                        quantity=qty, unit_price=price,
                        received_qty=received
                    )
                    total += qty * price
                po.total_amount = total
                po.save(update_fields=['total_amount'])
        self.stdout.write(f'  ✓ ใบสั่งซื้อ {len(pos)} ใบ')

        # === Goods Receipts ===
        gr_data = [
            {'gr_number': 'GR-2026-001', 'po': pos[0], 'receiver_name': 'สมชาย สมบูรณ์', 'receipt_date': today - timedelta(days=8)},
            {'gr_number': 'GR-2026-002', 'po': pos[2], 'receiver_name': 'สุภาพร ใจดี', 'receipt_date': today - timedelta(days=3)},
        ]
        grs = []
        for g in gr_data:
            gr, created = GoodsReceipt.objects.get_or_create(gr_number=g['gr_number'], defaults=g)
            grs.append(gr)
            if created:
                for po_line in g['po'].lines.all():
                    GRLine.objects.create(
                        gr=gr, po_line=po_line, item=po_line.item,
                        received_qty=po_line.received_qty,
                        condition_status='ปกติ'
                    )
        self.stdout.write(f'  ✓ ใบรับของ {len(grs)} ใบ')

        self.stdout.write(self.style.SUCCESS('\n✅ เพิ่มข้อมูลตัวอย่างเรียบร้อยแล้ว!'))
