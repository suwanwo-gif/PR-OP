from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.db.models import Sum, Count, Q, F, ProtectedError
from django.utils import timezone
from django.contrib.auth.decorators import login_required, user_passes_test
from django.forms import inlineformset_factory


from .models import (
    Vendor, Item,
    PurchaseRequisition, PRLine,
    PurchaseOrder, POLine,
    GoodsReceipt, GRLine,
)
from .forms import (
    VendorForm, ItemForm,
    PurchaseRequisitionForm, PRLineFormSet,
    PurchaseOrderForm, POLineFormSet, POLineForm,
    GoodsReceiptForm, GRLineFormSet, GRLineForm,
)


# ===== Role Check Helpers =====
def is_officer(user):
    return user.is_superuser or user.groups.filter(name='พนักงานจัดซื้อ').exists()

def is_manager(user):
    return user.is_superuser or user.groups.filter(name='หัวหน้าแผนกจัดซื้อ').exists()

def is_officer_or_manager(user):
    return user.is_superuser or user.groups.filter(name__in=['พนักงานจัดซื้อ', 'หัวหน้าแผนกจัดซื้อ']).exists()

def _restrict_pr_status(user, form):
    if not is_manager(user):
        form.fields['status'].choices = [
            ('ร่าง', 'ร่าง'),
            ('รออนุมัติ', 'รออนุมัติ'),
        ]

def _restrict_po_status(user, form):
    if not is_manager(user):
        # Allow officers to only save PO as Draft or Cancelled, but not issue it.
        # Sometimes officers might need to cancel their draft. 
        # But to be strictly "Manager only for issuing", restrict to ร่าง.
        current_status = form.instance.status if form.instance.pk else None
        
        # If PO is already something else, they probably shouldn't be editing it, but just in case:
        if current_status and current_status not in ['ร่าง', 'ยกเลิก']:
            form.fields['status'].choices = [(current_status, current_status)]
        else:
            form.fields['status'].choices = [
                ('ร่าง', 'ร่าง'),
                ('ยกเลิก', 'ยกเลิก'),
            ]


# ===== Dashboard =====

@login_required
def dashboard(request):
    """หน้าแดชบอร์ดหลัก"""
    today = timezone.now().date()

    # Counts
    pr_count = PurchaseRequisition.objects.count()
    pr_pending = PurchaseRequisition.objects.filter(status='รออนุมัติ').count()
    po_count = PurchaseOrder.objects.count()
    po_active = PurchaseOrder.objects.filter(status='ออกแล้ว').count()
    gr_count = GoodsReceipt.objects.count()
    vendor_count = Vendor.objects.count()
    item_count = Item.objects.count()

    # Total PO amount
    total_po_amount = PurchaseOrder.objects.exclude(
        status='ยกเลิก'
    ).aggregate(total=Sum('total_amount'))['total'] or 0

    # Recent PRs
    recent_prs = PurchaseRequisition.objects.order_by('-request_date', '-id')[:5]
    # Recent POs
    recent_pos = PurchaseOrder.objects.select_related('vendor').order_by('-order_date', '-id')[:5]
    # Recent GRs
    recent_grs = GoodsReceipt.objects.select_related('po').order_by('-receipt_date', '-id')[:5]

    # Monthly PO amount (current month)
    month_start = today.replace(day=1)
    monthly_po_amount = PurchaseOrder.objects.filter(
        order_date__gte=month_start,
        status__in=['ออกแล้ว', 'รับของครบ', 'รับของบางส่วน']
    ).aggregate(total=Sum('total_amount'))['total'] or 0

    context = {
        'pr_count': pr_count,
        'pr_pending': pr_pending,
        'po_count': po_count,
        'po_active': po_active,
        'gr_count': gr_count,
        'vendor_count': vendor_count,
        'item_count': item_count,
        'total_po_amount': total_po_amount,
        'monthly_po_amount': monthly_po_amount,
        'recent_prs': recent_prs,
        'recent_pos': recent_pos,
        'recent_grs': recent_grs,
    }
    return render(request, 'procurement/dashboard.html', context)


# ===== Vendor CRUD =====

@login_required
@user_passes_test(is_officer_or_manager)
def vendor_list(request):
    search = request.GET.get('q', '')
    vendors = Vendor.objects.all()
    if search:
        vendors = vendors.filter(
            Q(vendor_code__icontains=search) | Q(vendor_name__icontains=search)
        )
    return render(request, 'procurement/vendor_list.html', {'vendors': vendors, 'search': search})


@login_required
@user_passes_test(is_officer)
def vendor_create(request):
    if request.method == 'POST':
        form = VendorForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'เพิ่มผู้ขายสำเร็จ')
            return redirect('vendor_list')
    else:
        form = VendorForm()
    return render(request, 'procurement/vendor_form.html', {'form': form, 'title': 'เพิ่มผู้ขาย'})


@login_required
@user_passes_test(is_officer)
def vendor_edit(request, pk):
    vendor = get_object_or_404(Vendor, pk=pk)
    if request.method == 'POST':
        form = VendorForm(request.POST, instance=vendor)
        if form.is_valid():
            form.save()
            messages.success(request, 'แก้ไขผู้ขายสำเร็จ')
            return redirect('vendor_list')
    else:
        form = VendorForm(instance=vendor)
    return render(request, 'procurement/vendor_form.html', {'form': form, 'title': 'แก้ไขผู้ขาย'})


@login_required
@user_passes_test(is_officer)
def vendor_delete(request, pk):
    vendor = get_object_or_404(Vendor, pk=pk)
    if request.method == 'POST':
        try:
            vendor.delete()
            messages.success(request, 'ลบผู้ขายสำเร็จ')
        except Exception:
            messages.error(request, 'ไม่สามารถลบผู้ขายได้ เนื่องจากมีข้อมูลอ้างอิง')
        return redirect('vendor_list')
    return render(request, 'procurement/confirm_delete.html', {
        'object': vendor, 'title': 'ลบผู้ขาย', 'cancel_url': 'vendor_list'
    })


# ===== Item CRUD =====

@login_required
@user_passes_test(is_officer_or_manager)
def item_list(request):
    search = request.GET.get('q', '')
    items = Item.objects.all()
    if search:
        items = items.filter(
            Q(item_code__icontains=search) | Q(item_name__icontains=search)
        )
    return render(request, 'procurement/item_list.html', {'items': items, 'search': search})


@login_required
@user_passes_test(is_officer)
def item_create(request):
    if request.method == 'POST':
        form = ItemForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'เพิ่มสินค้าสำเร็จ')
            return redirect('item_list')
    else:
        form = ItemForm()
    return render(request, 'procurement/item_form.html', {'form': form, 'title': 'เพิ่มสินค้า'})


@login_required
@user_passes_test(is_officer)
def item_edit(request, pk):
    item = get_object_or_404(Item, pk=pk)
    if request.method == 'POST':
        form = ItemForm(request.POST, instance=item)
        if form.is_valid():
            form.save()
            messages.success(request, 'แก้ไขสินค้าสำเร็จ')
            return redirect('item_list')
    else:
        form = ItemForm(instance=item)
    return render(request, 'procurement/item_form.html', {'form': form, 'title': 'แก้ไขสินค้า'})


@login_required
@user_passes_test(is_officer)
def item_delete(request, pk):
    item = get_object_or_404(Item, pk=pk)
    if request.method == 'POST':
        try:
            item.delete()
            messages.success(request, 'ลบสินค้าสำเร็จ')
        except Exception:
            messages.error(request, 'ไม่สามารถลบสินค้าได้ เนื่องจากมีข้อมูลอ้างอิง')
        return redirect('item_list')
    return render(request, 'procurement/confirm_delete.html', {
        'object': item, 'title': 'ลบสินค้า', 'cancel_url': 'item_list'
    })


# ===== Purchase Requisition CRUD =====

@login_required
def pr_list(request):
    search = request.GET.get('q', '')
    status_filter = request.GET.get('status', '')
    
    if is_officer_or_manager(request.user):
        prs = PurchaseRequisition.objects.all()
    else:
        # General users see only their PRs
        prs = PurchaseRequisition.objects.filter(requester_user=request.user)
        
    if search:
        prs = prs.filter(
            Q(pr_number__icontains=search) | Q(requester_name__icontains=search)
        )
    if status_filter:
        prs = prs.filter(status=status_filter)
    return render(request, 'procurement/pr_list.html', {
        'prs': prs, 'search': search, 'status_filter': status_filter,
        'status_choices': PurchaseRequisition.STATUS_CHOICES,
    })


@login_required
def pr_detail(request, pk):
    pr = get_object_or_404(PurchaseRequisition, pk=pk)
    # Protection
    if not is_officer_or_manager(request.user) and pr.requester_user != request.user:
        messages.error(request, 'คุณไม่มีสิทธิ์เข้าถึงข้อมูลนี้')
        return redirect('pr_list')
        
    lines = pr.lines.select_related('item').all()
    return render(request, 'procurement/pr_detail.html', {'pr': pr, 'lines': lines})


@login_required
def pr_create(request):
    # Manager มีสิทธิ์เฉพาะอนุมัติ ไม่สามารถสร้าง PR ได้
    if is_manager(request.user) and not request.user.is_superuser:
        messages.error(request, 'คุณไม่มีสิทธิ์สร้างใบขอซื้อ')
        return redirect('pr_list')
    if request.method == 'POST':
        form = PurchaseRequisitionForm(request.POST)
        _restrict_pr_status(request.user, form)
        formset = PRLineFormSet(request.POST, prefix='lines')
        if form.is_valid() and formset.is_valid():
            pr = form.save(commit=False)
            pr.requester_user = request.user
            pr.save()
            formset.instance = pr
            formset.save()
            messages.success(request, f'สร้างใบขอซื้อ {pr.pr_number} สำเร็จ')
            return redirect('pr_detail', pk=pr.pk)
    else:
        form = PurchaseRequisitionForm()
        _restrict_pr_status(request.user, form)
        formset = PRLineFormSet(prefix='lines')
    return render(request, 'procurement/pr_form.html', {
        'form': form, 'formset': formset, 'title': 'สร้างใบขอซื้อ (PR)'
    })


@login_required
@user_passes_test(is_officer)
def pr_edit(request, pk):
    pr = get_object_or_404(PurchaseRequisition, pk=pk)
    if request.method == 'POST':
        form = PurchaseRequisitionForm(request.POST, instance=pr)
        _restrict_pr_status(request.user, form)
        formset = PRLineFormSet(request.POST, prefix='lines', instance=pr)
        if form.is_valid() and formset.is_valid():
            form.save()
            formset.save()
            messages.success(request, f'แก้ไขใบขอซื้อ {pr.pr_number} สำเร็จ')
            return redirect('pr_detail', pk=pr.pk)
    else:
        form = PurchaseRequisitionForm(instance=pr)
        _restrict_pr_status(request.user, form)
        formset = PRLineFormSet(prefix='lines', instance=pr)
    return render(request, 'procurement/pr_form.html', {
        'form': form, 'formset': formset, 'title': f'แก้ไขใบขอซื้อ {pr.pr_number}'
    })


@login_required
@user_passes_test(is_officer)
def pr_delete(request, pk):
    pr = get_object_or_404(PurchaseRequisition, pk=pk)
    if request.method == 'POST':
        pr.delete()
        messages.success(request, 'ลบใบขอซื้อสำเร็จ')
        return redirect('pr_list')
    return render(request, 'procurement/confirm_delete.html', {
        'object': pr, 'title': 'ลบใบขอซื้อ', 'cancel_url': 'pr_list'
    })


# ===== Purchase Order CRUD =====

@login_required
@user_passes_test(is_officer_or_manager)
def po_list(request):
    search = request.GET.get('q', '')
    status_filter = request.GET.get('status', '')
    pos = PurchaseOrder.objects.select_related('vendor').prefetch_related('lines__pr_line__pr').all()
    if search:
        pos = pos.filter(
            Q(po_number__icontains=search) | Q(vendor__vendor_name__icontains=search)
        )
    if status_filter:
        pos = pos.filter(status=status_filter)
    return render(request, 'procurement/po_list.html', {
        'pos': pos, 'search': search, 'status_filter': status_filter,
        'status_choices': PurchaseOrder.STATUS_CHOICES,
    })


@login_required
@user_passes_test(is_officer_or_manager)
def po_detail(request, pk):
    po = get_object_or_404(PurchaseOrder, pk=pk)
    lines = po.lines.select_related('item', 'pr_line__pr').all()
    grs = po.goodsreceipt_set.all()
    return render(request, 'procurement/po_detail.html', {'po': po, 'lines': lines, 'grs': grs})


@login_required
@user_passes_test(is_officer)
def po_create(request):
    if request.method == 'POST':
        form = PurchaseOrderForm(request.POST)
        _restrict_po_status(request.user, form)
        formset = POLineFormSet(request.POST, prefix='lines')
        if form.is_valid() and formset.is_valid():
            po = form.save()
            formset.instance = po
            formset.save()
            po.recalculate_total()
            messages.success(request, f'สร้างใบสั่งซื้อ {po.po_number} สำเร็จ')
            return redirect('po_detail', pk=po.pk)
    else:
        pr_id = request.GET.get('pr')
        if pr_id:
            form = PurchaseOrderForm(initial={'pr_reference': pr_id})
            _restrict_po_status(request.user, form)
            pr = get_object_or_404(PurchaseRequisition, pk=pr_id, status='อนุมัติ')
            initial_data = []
            for pl in pr.lines.all():
                initial_data.append({
                    'pr_line': pl,
                    'item': pl.item,
                    'quantity': pl.quantity,
                    'unit_price': pl.estimated_unit_price,
                })
            
            # Need to modify extra dynamically to avoid too many extra forms or not enough
            from django.forms import inlineformset_factory
            POLineFormSetMod = inlineformset_factory(
                PurchaseOrder, POLine,
                form=POLineForm,
                extra=len(initial_data),
                can_delete=True,
            )
            formset = POLineFormSetMod(prefix='lines', initial=initial_data)
        else:
            form = PurchaseOrderForm()
            _restrict_po_status(request.user, form)
            formset = POLineFormSet(prefix='lines')
    return render(request, 'procurement/po_form.html', {
        'form': form, 'formset': formset, 'title': 'สร้างใบสั่งซื้อ (PO)'
    })


@login_required
@user_passes_test(is_officer)
def po_edit(request, pk):
    po = get_object_or_404(PurchaseOrder, pk=pk)
    if request.method == 'POST':
        form = PurchaseOrderForm(request.POST, instance=po)
        _restrict_po_status(request.user, form)
        formset = POLineFormSet(request.POST, prefix='lines', instance=po)
        if form.is_valid() and formset.is_valid():
            form.save()
            formset.save()
            po.recalculate_total()
            messages.success(request, f'แก้ไขใบสั่งซื้อ {po.po_number} สำเร็จ')
            return redirect('po_detail', pk=po.pk)
    else:
        form = PurchaseOrderForm(instance=po)
        _restrict_po_status(request.user, form)
        formset = POLineFormSet(prefix='lines', instance=po)
    return render(request, 'procurement/po_form.html', {
        'form': form, 'formset': formset, 'title': f'แก้ไขใบสั่งซื้อ {po.po_number}'
    })


@login_required
@user_passes_test(is_officer)
def po_delete(request, pk):
    po = get_object_or_404(PurchaseOrder, pk=pk)
    if request.method == 'POST':
        try:
            po.delete()
            messages.success(request, 'ลบใบสั่งซื้อสำเร็จ')
        except ProtectedError:
            messages.error(request, 'ไม่สามารถลบใบสั่งซื้อนี้ได้ เนื่องจากมีการสร้างใบรับของ (GR) อ้างอิงไปแล้ว กรุณาลบใบรับของก่อน')
        return redirect('po_list')
    return render(request, 'procurement/confirm_delete.html', {
        'object': po, 'title': 'ลบใบสั่งซื้อ', 'cancel_url': 'po_list'
    })


# ===== Goods Receipt CRUD =====

@login_required
def gr_list(request):
    search = request.GET.get('q', '')
    grs = GoodsReceipt.objects.select_related('po', 'po__vendor').all()
    if search:
        grs = grs.filter(
            Q(gr_number__icontains=search) | Q(po__po_number__icontains=search)
        )
    return render(request, 'procurement/gr_list.html', {'grs': grs, 'search': search})


@login_required
def gr_detail(request, pk):
    gr = get_object_or_404(GoodsReceipt, pk=pk)
    lines = gr.lines.select_related('item', 'po_line__po').all()
    return render(request, 'procurement/gr_detail.html', {'gr': gr, 'lines': lines})


@login_required
@user_passes_test(is_officer)
def gr_create(request):
    if request.method == 'POST':
        form = GoodsReceiptForm(request.POST)
        formset = GRLineFormSet(request.POST, prefix='lines')
        if form.is_valid() and formset.is_valid():
            gr = form.save()
            formset.instance = gr
            formset.save()
            # Update received_qty on PO lines
            for gr_line in gr.lines.all():
                po_line = gr_line.po_line
                total_received = GRLine.objects.filter(
                    po_line=po_line
                ).aggregate(total=Sum('received_qty'))['total'] or 0
                po_line.received_qty = total_received
                po_line.save(update_fields=['received_qty'])
            # Update PO status
            _update_po_status(gr.po)
            messages.success(request, f'สร้างใบรับของ {gr.gr_number} สำเร็จ')
            return redirect('gr_detail', pk=gr.pk)
        # On POST error, try to restore po_info for re-display
        po_id = request.POST.get('po') or request.GET.get('po')
        po_info = None
        if po_id:
            try:
                po_info = PurchaseOrder.objects.get(pk=po_id)
            except PurchaseOrder.DoesNotExist:
                pass
    else:
        po_id = request.GET.get('po')
        po_info = None
        if po_id:
            po = get_object_or_404(PurchaseOrder, pk=po_id, status__in=['ออกแล้ว', 'รับของบางส่วน'])
            po_info = po
            form = GoodsReceiptForm(initial={'po': po})
            # Pre-fill GR lines from PO lines (only lines with remaining qty > 0)
            initial_lines = []
            for po_line in po.lines.all():
                remaining = po_line.quantity - po_line.received_qty
                if remaining > 0:
                    initial_lines.append({
                        'po_line': po_line,
                        'item': po_line.item,
                        'received_qty': remaining,
                        'condition_status': 'ปกติ',
                    })
            if initial_lines:
                GRLineFormSetPrefilled = inlineformset_factory(
                    GoodsReceipt, GRLine,
                    form=GRLineForm,
                    extra=len(initial_lines),
                    can_delete=True,
                )
                formset = GRLineFormSetPrefilled(prefix='lines', initial=initial_lines)
                # Filter po_line choices to this PO only
                for f in formset.forms:
                    f.fields['po_line'].queryset = po.lines.select_related('item')
            else:
                formset = GRLineFormSet(prefix='lines')
        else:
            form = GoodsReceiptForm()
            formset = GRLineFormSet(prefix='lines')
    return render(request, 'procurement/gr_form.html', {
        'form': form, 'formset': formset, 'title': 'สร้างใบรับของ (GR)', 'po_info': po_info,
    })


@login_required
@user_passes_test(is_officer)
def gr_edit(request, pk):
    gr = get_object_or_404(GoodsReceipt, pk=pk)
    if request.method == 'POST':
        form = GoodsReceiptForm(request.POST, instance=gr)
        formset = GRLineFormSet(request.POST, prefix='lines', instance=gr)
        if form.is_valid() and formset.is_valid():
            form.save()
            formset.save()
            # Recalculate received quantities
            for gr_line in gr.lines.all():
                po_line = gr_line.po_line
                total_received = GRLine.objects.filter(
                    po_line=po_line
                ).aggregate(total=Sum('received_qty'))['total'] or 0
                po_line.received_qty = total_received
                po_line.save(update_fields=['received_qty'])
            _update_po_status(gr.po)
            messages.success(request, f'แก้ไขใบรับของ {gr.gr_number} สำเร็จ')
            return redirect('gr_detail', pk=gr.pk)
    else:
        form = GoodsReceiptForm(instance=gr)
        formset = GRLineFormSet(prefix='lines', instance=gr)
    return render(request, 'procurement/gr_form.html', {
        'form': form, 'formset': formset, 'title': f'แก้ไขใบรับของ {gr.gr_number}'
    })


@login_required
@user_passes_test(is_officer)
def gr_delete(request, pk):
    gr = get_object_or_404(GoodsReceipt, pk=pk)
    if request.method == 'POST':
        po = gr.po
        gr.delete()
        # Recalculate after delete
        for po_line in po.lines.all():
            total_received = GRLine.objects.filter(
                po_line=po_line
            ).aggregate(total=Sum('received_qty'))['total'] or 0
            po_line.received_qty = total_received
            po_line.save(update_fields=['received_qty'])
        _update_po_status(po)
        messages.success(request, 'ลบใบรับของสำเร็จ')
        return redirect('gr_list')
    return render(request, 'procurement/confirm_delete.html', {
        'object': gr, 'title': 'ลบใบรับของ', 'cancel_url': 'gr_list'
    })


def _update_po_status(po):
    """Update PO status based on received quantities."""
    lines = po.lines.all()
    if not lines.exists():
        return
    all_received = all(line.received_qty >= line.quantity for line in lines)
    any_received = any(line.received_qty > 0 for line in lines)
    if all_received:
        po.status = 'รับของครบ'
    elif any_received:
        po.status = 'รับของบางส่วน'
    po.save(update_fields=['status'])


# ===== Approve Views (Manager Only) =====

@login_required
@user_passes_test(is_manager)
def pr_approve(request, pk):
    """Manager อนุมัติ / ไม่อนุมัติ PR"""
    pr = get_object_or_404(PurchaseRequisition, pk=pk)
    if pr.status != 'รออนุมัติ':
        messages.warning(request, f'ไม่สามารถอนุมัติได้ เนื่องจากสถานะปัจจุบันคือ «{pr.status}»')
        return redirect('pr_detail', pk=pk)
    action = request.POST.get('action')
    if request.method == 'POST' and action in ['อนุมัติ', 'ไม่อนุมัติ']:
        pr.status = action
        pr.save(update_fields=['status'])
        label = 'อนุมัติ' if action == 'อนุมัติ' else 'ไม่อนุมัติ'
        messages.success(request, f'{label}ใบขอซื้อ {pr.pr_number} เรียบร้อย')
    return redirect('pr_detail', pk=pk)


@login_required
@user_passes_test(is_manager)
def po_approve(request, pk):
    """Manager ออก PO (เปลี่ยนสถานะเป็น 'ออกแล้ว')"""
    po = get_object_or_404(PurchaseOrder, pk=pk)
    if po.status != 'ร่าง':
        messages.warning(request, f'ไม่สามารถออกใบสั่งซื้อได้ เนื่องจากสถานะปัจจุบันคือ «{po.status}»')
        return redirect('po_detail', pk=pk)
    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'ออกแล้ว':
            po.status = 'ออกแล้ว'
            po.save(update_fields=['status'])
            messages.success(request, f'ออกใบสั่งซื้อ {po.po_number} เรียบร้อย')
        elif action == 'ยกเลิก':
            po.status = 'ยกเลิก'
            po.save(update_fields=['status'])
            messages.success(request, f'ยกเลิกใบสั่งซื้อ {po.po_number} เรียบร้อย')
    return redirect('po_detail', pk=pk)
