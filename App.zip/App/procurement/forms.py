from django import forms
from .models import (
    Vendor, Item,
    PurchaseRequisition, PRLine,
    PurchaseOrder, POLine,
    GoodsReceipt, GRLine,
)


# ===== Widget helpers =====
FORM_INPUT_CLASS = 'form-control'
FORM_SELECT_CLASS = 'form-select'


def _add_class(field, css_class):
    """Add CSS class to a form field widget."""
    field.widget.attrs.setdefault('class', '')
    field.widget.attrs['class'] += f' {css_class}'
    return field


class StyledModelForm(forms.ModelForm):
    """Auto-apply Bootstrap classes to all fields."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name, field in self.fields.items():
            if isinstance(field.widget, (forms.Select, forms.SelectMultiple)):
                _add_class(field, FORM_SELECT_CLASS)
            elif isinstance(field.widget, forms.CheckboxInput):
                _add_class(field, 'form-check-input')
            else:
                _add_class(field, FORM_INPUT_CLASS)


# ===== Master Data =====

class VendorForm(StyledModelForm):
    class Meta:
        model = Vendor
        fields = ['vendor_code', 'vendor_name', 'tax_id', 'credit_term_days']


class ItemForm(StyledModelForm):
    class Meta:
        model = Item
        fields = ['item_code', 'item_name', 'category', 'uom']


# ===== Purchase Requisition =====

class PurchaseRequisitionForm(StyledModelForm):
    class Meta:
        model = PurchaseRequisition
        fields = ['requester_name', 'department', 'status', 'request_date']
        widgets = {
            'request_date': forms.DateInput(attrs={'type': 'date'}),
        }


class PRLineForm(StyledModelForm):
    class Meta:
        model = PRLine
        fields = ['item', 'quantity', 'estimated_unit_price']


PRLineFormSet = forms.inlineformset_factory(
    PurchaseRequisition, PRLine,
    form=PRLineForm,
    extra=1,
    can_delete=True,
)


# ===== Purchase Order =====

class PurchaseOrderForm(StyledModelForm):
    pr_reference = forms.ModelChoiceField(
        queryset=PurchaseRequisition.objects.filter(status='อนุมัติ'),
        required=False,
        label='ดึงข้อมูลจากใบขอซื้อ (PR)',
        empty_label='--- เลือก PR (เพื่อดึงรายการอัตโนมัติ) ---',
        help_text='หากเลือก ระบบจะดึงรายการสินค้ามาให้ทันที'
    )
    class Meta:
        model = PurchaseOrder
        fields = ['pr_reference', 'vendor', 'status', 'order_date']
        widgets = {
            'order_date': forms.DateInput(attrs={'type': 'date'}),
        }


class POLineForm(StyledModelForm):
    class Meta:
        model = POLine
        fields = ['pr_line', 'item', 'quantity', 'unit_price']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['pr_line'].required = True
        self.fields['pr_line'].queryset = PRLine.objects.filter(pr__status='อนุมัติ').select_related('pr', 'item')
        
    def clean(self):
        cleaned_data = super().clean()
        pr_line = cleaned_data.get('pr_line')
        if pr_line:
            # Auto-assign the item from PR line
            cleaned_data['item'] = pr_line.item
            if 'item' in self._errors:
                del self._errors['item']
        return cleaned_data


POLineFormSet = forms.inlineformset_factory(
    PurchaseOrder, POLine,
    form=POLineForm,
    extra=1,
    can_delete=True,
)


# ===== Goods Receipt =====

class GoodsReceiptForm(StyledModelForm):
    class Meta:
        model = GoodsReceipt
        fields = ['gr_number', 'po', 'receiver_name', 'receipt_date']
        widgets = {
            'receipt_date': forms.DateInput(attrs={'type': 'date'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['po'].queryset = PurchaseOrder.objects.filter(
            status__in=['ออกแล้ว', 'รับของบางส่วน']
        )


class GRLineForm(StyledModelForm):
    class Meta:
        model = GRLine
        fields = ['po_line', 'item', 'received_qty', 'condition_status']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['po_line'].queryset = POLine.objects.select_related('po', 'item')


GRLineFormSet = forms.inlineformset_factory(
    GoodsReceipt, GRLine,
    form=GRLineForm,
    extra=1,
    can_delete=True,
)
