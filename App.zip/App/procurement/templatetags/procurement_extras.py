from django import template

register = template.Library()

@register.filter
def can_access_procurement(user):
    return user.is_superuser or user.groups.filter(name__in=['พนักงานจัดซื้อ', 'หัวหน้าแผนกจัดซื้อ']).exists()

@register.filter
def is_manager_role(user):
    """Returns True if user is Manager only (not superuser, not officer)"""
    if user.is_superuser:
        return False
    return user.groups.filter(name='หัวหน้าแผนกจัดซื้อ').exists()

@register.filter
def is_officer_role(user):
    """Returns True if user is Officer or superuser"""
    return user.is_superuser or user.groups.filter(name='พนักงานจัดซื้อ').exists()
